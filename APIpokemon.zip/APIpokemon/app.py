
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import requests
import logging
api_url = "https://pokeapi.co/api/v2/pokemon/"

app = Flask(__name__)

app.secret_key = 'chaRRIsarSecreta123'

logging.basicConfig(level=logging.INFO)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/buscar', methods=["POST"])
def buscar():
    pokemon_name = request.form.get('name', '').strip().lower()
    if not pokemon_name:
        flash('!!¿Cuál es  ese pokémon?!!', 'error')
        logging.warning(f"Búsqueda vacía desde {request.remote_addr}")
        return redirect(url_for('index'))

    logging.info(f"Búsqueda de Pokémon: {pokemon_name} desde {request.remote_addr}")

    try:
        resp = requests.get(f"{api_url}{pokemon_name}")
        if resp.status_code == 200:
            pokemon_data = resp.json()
            pokemon_info= {
                'name': pokemon_data['name'].title(),
                'id': pokemon_data['id'],
                'height': pokemon_data['height']/10,
                'weight': pokemon_data['weight']/10,
                'sprite': pokemon_data['sprites']['front_default'],
                'shiny': pokemon_data['sprites']['front_shiny'],
                'abilities':[a['ability']['name'].title() for a in pokemon_data['abilities']],
                'types': [t['type']['name'].title() for t in pokemon_data['types']],
            }
            logging.info(f"Pokémon encontrado: {pokemon_name} (ID: {pokemon_data['id']})")
            return render_template('pokémon.html', pokemon=pokemon_info)
        else:
            flash('No pudimos localizar a tu pokémon :(', 'error')
            logging.warning(f"Pokémon no encontrado: {pokemon_name} (Status: {resp.status_code})")
            return redirect(url_for('index'))
    except requests.exceptions.RequestException as e:
        flash('No se encuentra en el pokeDex', 'error')
        logging.error(f"Error de conexión al buscar {pokemon_name}: {str(e)}")
        return redirect(url_for('index'))

@app.route('/api-data')
def get_api_data():
    try:
        response = requests.get('https://pokeapi.co/api/v2')
        data = response.json()
        return jsonify(data)
    except requests.exceptions.RequestException as e:
        logging.error(f"Error al obtener datos de la API: {str(e)}")
        return jsonify({'error':'No se pudo conectar'}), 500


if __name__ == '__main__':
    app.run(debug=True)